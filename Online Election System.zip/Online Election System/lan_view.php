<?php
if(!isset($_SESSION)) {
session_start();
}
include "auth.php";
include "header_voter.php";
?>
<center><h3> Voting So Far  </h3></center>
<?php
include "connection.php";
$member = mysqli_query($con, 'SELECT * FROM  voters' );
if (mysqli_num_rows($member)== 0 ) {
	echo '<font color="red">No results found</font>';
}
else {
	echo '<center><table><tr bgcolor="#FF6600">
<td width="30px">FIRST NAME</td>
<td width="100px">LAST NAME</td>
<td width="100px">USER NAME</td>
<td width="100px">STATUS</td>
<td width="30px">VOTE</td>
</tr>';
while($mb=mysqli_fetch_object($member))
		{
			$fname=$mb->firstname;
			$stat=$mb->status;
			$vote=$mb->voted;
			$lname=$mb->lastname;
			$usern=$mb->username;
			echo '<tr bgcolor="#BBBEFF">';
	echo '<td>'.$fname.'</td>';
	echo '<td>'.$lname.'</td>';
	echo '<td>'.$usern.'</td>';
	echo '<td>'.$stat.'</td>';
	echo '<td>'.$vote.'</td>';
	echo "</tr>";
		}
		echo'</table></center>';
	}
?>
